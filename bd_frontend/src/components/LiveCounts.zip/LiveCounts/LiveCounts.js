import React, { Fragment, useState, useEffect } from 'react';
import Header from '../../components/header/Header';
import PageTitle from '../../components/pagetitle/PageTitle';
import Scrollbar from '../../components/scrollbar/scrollbar';
import Footer from '../../components/footer/Footer';
import Graph1 from './Graph1';
import Graph2 from './Graph2';
import './charts.css';
import axios from 'axios'

const StatisticsPage = (props) => {
    const [collegesData, setColleges] = useState("");
    const [totalCounts, setTotalCounts] = useState({ attended: 0, showedInterest: 0 });
    const CollegeName = {
        "": "All Colleges",
        "AEC": "Aditya Engineering College",
        "ACOE": "Aditya College of Engineering"
    };

    const [noEvent, setNoEvent] = useState(false);

    const [option, setOption] = useState('');
    const handleChange = (event) => {
        setOption(event.target.value);
    };

    const port = process.env.REACT_APP_SERVER_PORT;

    // Calculate total counts based on data
    useEffect(() => {

        const fun1 = async () => {
            const today = new Date();
            const venues = await axios.post(port + "get-venues", {
                "date": today.toISOString().split('T')[0],
            })
            setColleges(venues.data.Place);

            venues.data.Place.forEach(name => {
                CollegeName[String(name)] = String(name);
            });

            // console.log(CollegeName)
            // console.log(venues.data.Place)

            // console.log(collegesData.Place);
            // console.log("Called")
        }
        fun1();

        // Replace this logic with your API or data-fetching logic
        const data = {
            showedInterest: [4000, 3000, 9000, 3808, 4800, 3800, 4300],
            attended: [2400, 1398, 2800, 2980, 1890, 2390, 3490],
        };

        const totalShowedInterest = data.showedInterest.reduce((a, b) => a + b, 0);
        const totalAttended = data.attended.reduce((a, b) => a + b, 0);

        const fun = (async () => {
            const upcomingEvent = await axios.get(port + 'get-upcoming-event');
            if (upcomingEvent.status === 200) {
                const eventDate = new Date(upcomingEvent.data.Date);
                const today = new Date();


                const formattedEventDate = eventDate.toISOString().split('T')[0]; //GPT
                const formattedToday = today.toISOString().split('T')[0]; //GPT

                if (formattedEventDate === formattedToday) {
                    setNoEvent(false);
                } else {
                    setNoEvent(true);
                }
            } else {
                setNoEvent(true);
            }
        });
        fun();



        // setTotalCounts({ attended: totalAttended, showedInterest: totalShowedInterest });

        // const collegeDataResponse = axios.get(port + `get-college-data`);


    }, [option]);

    return (
        <Fragment>
            <Header hclass={'header--styleFour'} />
            <main className='main'>
                <PageTitle pageTitle={'LIVE STATISTICS'} pagesub={'LIVE  STATISTICS'} />

                {!noEvent &&
                    <section className="about">

                        <div className="header-stat">

                            <div className='drop-down-clgs'>
                                {/* <span className="sectionTitle__small" style={{justifySelf: "center"}}>
                                    <i className="fa-solid fa-heart btn__icon"></i>
                                    Contact Us Here
                                </span> */}


                                <select value={option} onChange={handleChange} className='dropdown-btn'>
                                    <option value="" className='dropdown-content'>All Colleges</option>
                                    {collegesData && collegesData.map(college => {
                                        return <option key={college} value={college} className='dropdown-content'>{college}</option>
                                    })}
                                </select>
                            </div>
                        </div>
                        <div className='graph-container' style={{ margin: 0 }}>

                            <u style={{ color: "black" }}>
                                {/* {console.log(option + " " + CollegeName[option])} */}
                                <h3 className="sectionTitle__big">{CollegeName[option] || option}</h3>
                            </u>
                            <div className="liveCounts" style={{ marginTop: "20px", marginBottom: "-50px" }}>
                                <h4>Live donor count: {totalCounts.attended}</h4>
                            </div>
                            <div className='Graphs-1' style={{ marginTop: "70px", marginBottom: "10px" }}>
                                <Graph1 college={option} setTotalCounts={setTotalCounts} />
                            </div>
                        </div>
                    </section>
                }
                {noEvent && <div className="headForContact">
                    <span className="sectionTitle__small">
                        <i className="fa-solid fa-user btn__icon"></i>
                        Live Stats
                    </span>
                </div>}
                {noEvent && <div className='form-container' style={{ height: "300px", display: "flex", alignItems: "center", justifyContent: "center", color: "black", fontSize: "30px", wordSpacing: "5px" }}>NO ONGOING EVENTS AT THE MOMENT</div>}
            </main>



            <Footer />
            <Scrollbar />
        </Fragment>
    );
};

export default StatisticsPage;
